package com.example.demo.controller;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class HomeController {
	
	@RequestMapping("/")
    public String index() {
        return "index";
    }
	 @RequestMapping("")
	    public String rooot() {
	        return "index";
	    }

	 @GetMapping("/login.html")
	    public String getLoginPage(){
	        return "lllogin";
	    }
	 @GetMapping("/registration.html")
	    public String getSignUpPage(){
	        return "SignUpPage";
	    }
	 @GetMapping("/userlogin.html")
	    public String getUserLoginPage(){
	        return "userlogin";
	    }
	 @GetMapping("/userSignUp.html")
	    public String getUserSignUpPage(){
	        return "userSignUp";
	    }
	 @GetMapping("/trains.html")
	    public String getDisplayTrainPage(){
	        return "trains";
	    }
	 @GetMapping("/src_des.html")
	    public String getsrcdesPage(){
	        return "src_des";
	    }
	 @GetMapping("/TicketBooking.html")
	    public String getTicketBookingPage(){
	        return "TicketBooking";
	    }
	 @GetMapping("/pppassengers.html")
	    public String getpppassengersPage(){
	        return "pppassengers";
	    }
	 @GetMapping("/paymentpage.html")
	    public String getPaymentPage(){
	        return "paymentpage";
	    }
	 @GetMapping("/finalticket.html")
	    public String getFinalTicketPage(){
	        return "finalticket";
	    }
	 @GetMapping("/adminLogin.html")
	    public String getAdminLoginPage(){
	        return "adminLogin";
	    }
	 @GetMapping("/index.html")
	    public String getIndexPage(){
	        return "index";
	    }
	 @GetMapping("/Passenger.html")
	    public String getPassengerPage(){
	        return "Passenger";
	    }
	 @GetMapping("/addPassenger.html")
	    public String getAddPassengerPage(){
	        return "AddPassenger";
	    }
	 @GetMapping("/updatePassenger.html")
	    public String getupdatePassengerPage(){
	        return "updatePassenger";
	    }
	 @GetMapping("/deletePassenger.html")
	    public String getDeletePassengerPage(){
	        return "deletePassenger";
	    }
	 @GetMapping("/showPassenger.html")
	    public String getShowPassengerPage(){
	        return "showPassenger";
	    }
	 @GetMapping("/Train.html")
	    public String getTrainPage(){
	        return "Train";
	    }
	 @GetMapping("/addTrain.html")
	    public String getAddTrainPage(){
	        return "addTrain";
	    }
	 @GetMapping("/updateTrain.html")
	    public String getupdateTrainPage(){
	        return "updateTrain";
	    }
	 @GetMapping("/deleteTrain.html")
	    public String getDeleteTrainPage(){
	        return "deleteTrain";
	    }
	 @GetMapping("/showTrain.html")
	    public String getShowTrainPage(){
	        return "showTrain";
	    }
	 @GetMapping("/GetTrains.html")
	    public String getTrainsPage(){
	        return "GetTrains";
	    }
	 @GetMapping("/Ticket.html")
	    public String getTicketPage(){
	        return "Ticket";
	    }
	 @GetMapping("/bookticket.html")
	    public String getBookTicketPage(){
	        return "bookticket";
	    }
	 @GetMapping("/getticket.html")
	    public String getTicketsPage(){
	        return "getticket";
	    }
}
